import pptxgen from 'pptxgenjs';

export async function generateOrganDonationPPT() {
  const pptx = new pptxgen();

  // Set presentation properties
  pptx.author = 'NSS - TNACE';
  pptx.title = 'अंगदान जीवन संजीवनी अभियान';
  pptx.subject = 'Organ Donation Awareness Programme';
  pptx.company = 'National Service Scheme';

  // Define colors
  const colors = {
    darkBg: '0f172a',
    teal: '14b8a6',
    emerald: '10b981',
    red: 'ef4444',
    amber: 'f59e0b',
    blue: '3b82f6',
    purple: 'a855f7',
    white: 'ffffff',
    lightGray: 'cbd5e1',
    darkGray: '64748b',
  };

  // ============ SLIDE 1: Title Slide ============
  let slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };
  
  slide.addText('🇮🇳 NATIONAL SERVICE SCHEME (NSS)', {
    x: 0.5, y: 0.3, w: 9, h: 0.4,
    fontSize: 14, color: colors.teal, bold: true,
    align: 'center',
  });

  slide.addText('अंगदान', {
    x: 0.5, y: 1.2, w: 9, h: 1,
    fontSize: 60, color: colors.white, bold: true,
    align: 'center',
  });

  slide.addText('जीवन संजीवनी अभियान', {
    x: 0.5, y: 2.2, w: 9, h: 0.8,
    fontSize: 36, color: colors.teal, bold: true,
    align: 'center',
  });

  slide.addText('"एक अंगदान - आठ जिंदगियाँ" | Organ Donation Awareness Programme', {
    x: 0.5, y: 3.2, w: 9, h: 0.5,
    fontSize: 16, color: colors.lightGray,
    align: 'center',
  });

  slide.addText('❤️', {
    x: 4.5, y: 3.8, w: 1, h: 0.8,
    fontSize: 48, align: 'center',
  });

  // Event details table
  const eventData: pptxgen.TableRow[] = [
    [{ text: '📅 Date' }, { text: 'Tuesday, 2026' }],
    [{ text: '📍 Venue' }, { text: 'TN Campus & Hargaon Village' }],
    [{ text: '👤 Convener' }, { text: 'Dr. Rahul Kumar Pandey (Principal, TNACE)' }],
    [{ text: '👥 Coordinator' }, { text: 'Dr. P.M. Jena Ma\'am (Asst. Prof., TSC)' }],
  ];

  slide.addTable(eventData, {
    x: 1.5, y: 4.5, w: 7, h: 1.5,
    fontSize: 11,
    color: colors.white,
    fill: { color: '1e293b' },
    border: { type: 'solid', color: '334155', pt: 1 },
    align: 'left',
    valign: 'middle',
  });

  // ============ SLIDE 2: What is Organ Donation ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('अंगदान क्या है? (What is Organ Donation?)', {
    x: 0.5, y: 0.3, w: 9, h: 0.6,
    fontSize: 28, color: colors.white, bold: true,
  });

  slide.addText('परिभाषा (Definition):', {
    x: 0.5, y: 1.1, w: 9, h: 0.4,
    fontSize: 18, color: colors.teal, bold: true,
  });

  slide.addText(
    'अंगदान (Organ Donation) वह प्रक्रिया है जिसमें एक व्यक्ति अपने शरीर के स्वस्थ अंग (organs) या ऊतक (tissues) किसी जरूरतमंद मरीज़ को प्रत्यारोपण (transplant) के लिए देता है।\n\nयह जीवित (Living) या मृत्यु के बाद (After Death) — दोनों तरीकों से हो सकता है।',
    {
      x: 0.5, y: 1.5, w: 9, h: 1.2,
      fontSize: 14, color: colors.lightGray,
      align: 'left',
    }
  );

  const keyPoints = [
    ['🫀', 'जीवन का उपहार', 'अंगदान किसी इंसान को दिया जाने वाला सबसे बड़ा उपहार है — जीवन का उपहार।'],
    ['🏥', 'Transplantation Surgery', 'डॉक्टर मरीज़ के खराब अंग को हटाकर, दान किए गए स्वस्थ अंग को लगाते हैं।'],
    ['8️⃣', '1 Donor = 8 Lives', 'एक अंगदाता 8 लोगों की जान बचा सकता है और 75+ लोगों की ज़िंदगी सुधार सकता है!'],
    ['⏰', 'Waiting List Crisis', 'भारत में हर साल 5 लाख+ लोग अंग प्रत्यारोपण का इंतज़ार करते हैं।'],
    ['💡', 'जागरूकता की जरूरत', 'अंगदान के बारे में जानकारी की कमी सबसे बड़ी बाधा है।'],
  ];

  keyPoints.forEach((point, idx) => {
    slide.addText(`${point[0]} ${point[1]}`, {
      x: 0.5, y: 2.9 + idx * 0.55, w: 9, h: 0.3,
      fontSize: 13, color: colors.white, bold: true,
    });
    slide.addText(point[2], {
      x: 0.8, y: 3.15 + idx * 0.55, w: 8.5, h: 0.25,
      fontSize: 10, color: colors.darkGray,
    });
  });

  // ============ SLIDE 3: Which Organs Can Be Donated ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('कौन-कौन से अंग दान किए जा सकते हैं?', {
    x: 0.5, y: 0.3, w: 9, h: 0.5,
    fontSize: 26, color: colors.white, bold: true,
  });

  slide.addText('Which organs & tissues can be donated?', {
    x: 0.5, y: 0.75, w: 9, h: 0.3,
    fontSize: 12, color: colors.darkGray,
  });

  const organs = [
    ['🫀 Heart (हृदय)', '4-6 hours', '🫁 Lungs (फेफड़े)', '6-8 hours'],
    ['🟤 Liver (यकृत)', '12-15 hours', '🫘 Kidneys (गुर्दे)', '24-48 hours'],
    ['🟡 Pancreas (अग्न्याशय)', '12-24 hours', '🔵 Intestines (आंतें)', '8-12 hours'],
    ['👁️ Cornea (कॉर्निया)', '14 days', '🦴 Bones (हड्डियाँ)', '5 years'],
    ['🩸 Bone Marrow', 'Living Donor', '🟠 Skin (त्वचा)', '5 years'],
    ['❤️ Heart Valves', '10 years', '🩹 Tendons (कण्डरा)', '5 years'],
  ];

  organs.forEach((row, idx) => {
    slide.addText(row[0], {
      x: 0.5, y: 1.3 + idx * 0.6, w: 3.5, h: 0.3,
      fontSize: 12, color: colors.white, bold: true,
    });
    slide.addText(`⏱ ${row[1]}`, {
      x: 0.5, y: 1.55 + idx * 0.6, w: 3.5, h: 0.25,
      fontSize: 9, color: colors.teal,
    });
    slide.addText(row[2], {
      x: 5, y: 1.3 + idx * 0.6, w: 3.5, h: 0.3,
      fontSize: 12, color: colors.white, bold: true,
    });
    slide.addText(`⏱ ${row[3]}`, {
      x: 5, y: 1.55 + idx * 0.6, w: 3.5, h: 0.25,
      fontSize: 9, color: colors.teal,
    });
  });

  slide.addShape(pptx.ShapeType.rect, {
    x: 0.5, y: 4.9, w: 9, h: 0.6,
    fill: { color: '134e4a' },
    line: { color: colors.teal, pt: 1 },
  });

  slide.addText('💡 एक अंगदाता 8 जिंदगियाँ बचा सकता है और 75+ लोगों की ज़िंदगी सुधार सकता है!', {
    x: 0.5, y: 5, w: 9, h: 0.5,
    fontSize: 13, color: colors.white, bold: true,
    align: 'center',
  });

  // ============ SLIDE 4: Types of Donation ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('अंगदान के प्रकार (Types of Organ Donation)', {
    x: 0.5, y: 0.3, w: 9, h: 0.5,
    fontSize: 26, color: colors.white, bold: true,
  });

  // Living Donation Box
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 0.3, y: 1, w: 4.4, h: 2.8,
    fill: { color: '064e3b' },
    line: { color: colors.emerald, pt: 1 },
  });

  slide.addText('🟢 जीवित दान (Living Donation)', {
    x: 0.5, y: 1.1, w: 4, h: 0.4,
    fontSize: 14, color: colors.emerald, bold: true,
  });

  const livingPoints = [
    '✅ जीवित व्यक्ति अपना एक अंग दान करता है',
    '✅ आमतौर पर एक किडनी या लिवर का हिस्सा',
    '✅ दाता सामान्य जीवन जी सकता है',
    '✅ परिवार के सदस्य दान कर सकते हैं',
    '✅ Bone Marrow भी जीवित दान में आता है',
  ];

  livingPoints.forEach((point, idx) => {
    slide.addText(point, {
      x: 0.5, y: 1.6 + idx * 0.4, w: 4, h: 0.35,
      fontSize: 10, color: colors.lightGray,
    });
  });

  // Deceased Donation Box
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 5.3, y: 1, w: 4.4, h: 2.8,
    fill: { color: '1e3a5f' },
    line: { color: colors.blue, pt: 1 },
  });

  slide.addText('🔵 मृत्यु के बाद दान (Deceased Donation)', {
    x: 5.5, y: 1.1, w: 4, h: 0.4,
    fontSize: 14, color: colors.blue, bold: true,
  });

  const deceasedPoints = [
    '💙 Brain Death के बाद अंगदान होता है',
    '💙 Heart, Lungs, Liver, Kidneys सब दान हो सकते हैं',
    '💙 एक मृत दाता 8 जिंदगियाँ बचा सकता है',
    '💙 Cornea सामान्य मृत्यु के बाद भी हो सकता है',
    '💙 परिवार की सहमति आवश्यक है',
  ];

  deceasedPoints.forEach((point, idx) => {
    slide.addText(point, {
      x: 5.5, y: 1.6 + idx * 0.4, w: 4, h: 0.35,
      fontSize: 10, color: colors.lightGray,
    });
  });

  // Brain Death Box
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 0.3, y: 4, w: 9.4, h: 1.3,
    fill: { color: '78350f' },
    line: { color: colors.amber, pt: 1 },
  });

  slide.addText('🧠 Brain Death (ब्रेन डेथ) क्या है?', {
    x: 0.5, y: 4.1, w: 9, h: 0.35,
    fontSize: 13, color: colors.amber, bold: true,
  });

  slide.addText(
    'जब मस्तिष्क पूरी तरह काम करना बंद कर देता है और कभी ठीक नहीं हो सकता — यह कानूनी तौर पर मृत्यु मानी जाती है। इस स्थिति में ventilator से शरीर के बाकी अंग काम करते रहते हैं। 4 डॉक्टरों की टीम Brain Death को certify करती है।',
    {
      x: 0.5, y: 4.5, w: 9, h: 0.7,
      fontSize: 10, color: colors.lightGray,
    }
  );

  // ============ SLIDE 5: How It Works ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('अंगदान कैसे होता है? (How Does It Work?)', {
    x: 0.5, y: 0.3, w: 9, h: 0.5,
    fontSize: 26, color: colors.white, bold: true,
  });

  const steps = [
    ['01', '📝 रजिस्ट्रेशन', 'NOTTO वेबसाइट पर रजिस्टर करें', colors.teal],
    ['02', '👨‍👩‍👧‍👦 परिवार को बताएं', 'अपने निर्णय के बारे में बताएं', colors.blue],
    ['03', '🏥 Brain Death घोषणा', '4 डॉक्टर Brain Death certify करते हैं', colors.purple],
    ['04', '🔄 अंग मिलान', 'NOTTO से जरूरतमंद मरीज़ का मिलान', colors.amber],
    ['05', '✂️ अंग निकालना', 'Trained surgeons अंग निकालते हैं', colors.red],
    ['06', '🚑 Green Corridor', 'ट्रैफ़िक-फ़्री रूट से अस्पताल तक', '22c55e'],
    ['07', '🫀 ट्रांसप्लांट', 'मरीज़ में अंग प्रत्यारोपण', 'ec4899'],
    ['08', '🌟 नई ज़िंदगी!', 'मरीज़ को नया जीवन मिलता है!', colors.emerald],
  ];

  steps.forEach((step, idx) => {
    const col = idx % 2;
    const row = Math.floor(idx / 2);

    slide.addShape(pptx.ShapeType.ellipse, {
      x: 0.5 + col * 5, y: 1 + row * 1.1, w: 0.5, h: 0.5,
      fill: { color: step[3] },
    });

    slide.addText(step[0], {
      x: 0.5 + col * 5, y: 1.05 + row * 1.1, w: 0.5, h: 0.4,
      fontSize: 11, color: colors.white, bold: true,
      align: 'center',
    });

    slide.addText(step[1], {
      x: 1.1 + col * 5, y: 1 + row * 1.1, w: 3.5, h: 0.3,
      fontSize: 12, color: colors.white, bold: true,
    });

    slide.addText(step[2], {
      x: 1.1 + col * 5, y: 1.28 + row * 1.1, w: 3.5, h: 0.25,
      fontSize: 9, color: colors.darkGray,
    });
  });

  // ============ SLIDE 6: Why Important ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('अंगदान क्यों ज़रूरी है? (Why is it Important?)', {
    x: 0.5, y: 0.3, w: 9, h: 0.5,
    fontSize: 26, color: colors.white, bold: true,
  });

  const reasons = [
    ['💀', 'हर दिन 20+ मरीज़ मर जाते हैं', '20+/day', 'अंग न मिलने से हर दिन 20+ लोगों की मौत'],
    ['📉', 'बहुत कम दान दर', '0.52 pmp', 'भारत में 0.52 vs स्पेन में 49.6'],
    ['⏳', '5 लाख+ Waiting List', '5,00,000+', 'हर साल 5 लाख+ लोग इंतज़ार करते हैं'],
    ['👁️', 'लाखों लोग अंधे हैं', '12 Lakh+', 'कॉर्निया के इंतज़ार में'],
    ['🫘', 'किडनी की सबसे ज़्यादा ज़रूरत', '2 Lakh+', 'केवल 10-12 हज़ार को मिलती है'],
    ['🌍', 'Organ Trafficking रोकें', 'Stop Crime', 'वैध दान से अवैध तस्करी रुकेगी'],
  ];

  reasons.forEach((reason, idx) => {
    const col = idx % 3;
    const row = Math.floor(idx / 3);

    slide.addShape(pptx.ShapeType.roundRect, {
      x: 0.3 + col * 3.2, y: 1 + row * 1.9, w: 3, h: 1.7,
      fill: { color: '1e293b' },
      line: { color: '334155', pt: 1 },
    });

    slide.addText(reason[0], {
      x: 0.5 + col * 3.2, y: 1.1 + row * 1.9, w: 2.6, h: 0.4,
      fontSize: 24, align: 'center',
    });

    slide.addText(reason[1], {
      x: 0.5 + col * 3.2, y: 1.5 + row * 1.9, w: 2.6, h: 0.35,
      fontSize: 10, color: colors.white, bold: true,
      align: 'center',
    });

    slide.addText(reason[2], {
      x: 0.5 + col * 3.2, y: 1.85 + row * 1.9, w: 2.6, h: 0.3,
      fontSize: 11, color: colors.teal, bold: true,
      align: 'center',
    });

    slide.addText(reason[3], {
      x: 0.5 + col * 3.2, y: 2.15 + row * 1.9, w: 2.6, h: 0.35,
      fontSize: 8, color: colors.darkGray,
      align: 'center',
    });
  });

  // Impact Bar
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 0.3, y: 4.9, w: 9.4, h: 0.7,
    fill: { color: '134e4a' },
    line: { color: colors.teal, pt: 1 },
  });

  slide.addText('5,00,000+ Need → 15,000 Get Transplants → 97% Die Waiting 😢', {
    x: 0.5, y: 5, w: 9, h: 0.5,
    fontSize: 14, color: colors.white, bold: true,
    align: 'center',
  });

  // ============ SLIDE 7: India Stats ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('भारत का Data (India\'s Organ Donation Statistics)', {
    x: 0.5, y: 0.3, w: 9, h: 0.5,
    fontSize: 24, color: colors.white, bold: true,
  });

  // Global Comparison
  slide.addText('🌍 वैश्विक तुलना (per million population)', {
    x: 0.5, y: 0.9, w: 4.5, h: 0.35,
    fontSize: 12, color: colors.teal, bold: true,
  });

  const countries: [string, string, number][] = [
    ['🇪🇸 Spain', '49.6', 100],
    ['🇺🇸 USA', '41.8', 84],
    ['🇫🇷 France', '33.0', 66],
    ['🇬🇧 UK', '23.0', 46],
    ['🇧🇷 Brazil', '17.0', 34],
    ['🇮🇳 India', '0.52', 3],
  ];

  countries.forEach((country, idx) => {
    slide.addText(country[0], {
      x: 0.5, y: 1.3 + idx * 0.45, w: 1.5, h: 0.3,
      fontSize: 10, color: colors.white,
    });

    slide.addShape(pptx.ShapeType.rect, {
      x: 2, y: 1.35 + idx * 0.45, w: 2.5, h: 0.2,
      fill: { color: '334155' },
    });

    slide.addShape(pptx.ShapeType.rect, {
      x: 2, y: 1.35 + idx * 0.45, w: country[2] * 0.025, h: 0.2,
      fill: { color: idx === 5 ? colors.red : colors.emerald },
    });

    slide.addText(country[1], {
      x: 4.6, y: 1.3 + idx * 0.45, w: 0.6, h: 0.3,
      fontSize: 9, color: idx === 5 ? colors.red : colors.lightGray,
    });
  });

  // Organ-wise Gap
  slide.addText('🇮🇳 अंग-वार कमी (Organ-wise Gap)', {
    x: 5.3, y: 0.9, w: 4.5, h: 0.35,
    fontSize: 12, color: colors.teal, bold: true,
  });

  const organGaps = [
    ['🫘 Kidney', '2,00,000+', '10-12K', '95%'],
    ['🟤 Liver', '50,000+', '3,500', '93%'],
    ['🫀 Heart', '50,000+', '250-300', '99%'],
    ['👁️ Cornea', '12,00,000+', '50,000', '96%'],
  ];

  organGaps.forEach((organ, idx) => {
    slide.addShape(pptx.ShapeType.roundRect, {
      x: 5.3, y: 1.3 + idx * 0.85, w: 4.4, h: 0.75,
      fill: { color: '1e293b' },
      line: { color: '334155', pt: 1 },
    });

    slide.addText(organ[0], {
      x: 5.5, y: 1.35 + idx * 0.85, w: 2, h: 0.3,
      fontSize: 10, color: colors.white, bold: true,
    });

    slide.addText(`ज़रूरत: ${organ[1]}`, {
      x: 5.5, y: 1.65 + idx * 0.85, w: 1.5, h: 0.25,
      fontSize: 8, color: colors.red,
    });

    slide.addText(`उपलब्ध: ${organ[2]}`, {
      x: 7, y: 1.65 + idx * 0.85, w: 1.3, h: 0.25,
      fontSize: 8, color: colors.emerald,
    });

    slide.addText(`Gap: ${organ[3]}`, {
      x: 8.3, y: 1.65 + idx * 0.85, w: 1, h: 0.25,
      fontSize: 8, color: colors.amber,
    });
  });

  // Bottom stats
  slide.addText('📝 Registered Donors: 4.5 Lakh+ | 💙 Deceased Donors (2023): 1,028 | 🏆 Top State: Tamil Nadu | 📞 NOTTO: 1800-11-4770', {
    x: 0.3, y: 5.2, w: 9.4, h: 0.4,
    fontSize: 10, color: colors.lightGray,
    align: 'center',
  });

  // ============ SLIDE 8: Myths vs Facts ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('भ्रम vs सच्चाई (Myths vs Facts)', {
    x: 0.5, y: 0.3, w: 9, h: 0.5,
    fontSize: 26, color: colors.white, bold: true,
  });

  const mythsFacts = [
    ['अंगदान धर्म के विरुद्ध है', 'सभी प्रमुख धर्म अंगदान का समर्थन करते हैं। यह महादान है।'],
    ['डॉक्टर इलाज ठीक से नहीं करेंगे', 'डॉक्टर की पहली प्राथमिकता जान बचाना है। दान Brain Death के बाद होता है।'],
    ['बूढ़े लोग दान नहीं कर सकते', 'उम्र कोई बाधा नहीं! 85+ साल के लोगों ने भी दान किया है।'],
    ['शरीर बिगड़ जाता है', 'शरीर को पूरे सम्मान से वापस किया जाता है। सामान्य अंतिम संस्कार हो सकता है।'],
    ['केवल अमीरों को अंग मिलते हैं', 'NOTTO कंप्यूटर मिलान करता है — कोई भेदभाव नहीं।'],
    ['दाता परिवार को पैसे देने होते हैं', 'अंगदान पूरी तरह नि:शुल्क है!'],
  ];

  mythsFacts.forEach((item, idx) => {
    const yPos = 0.9 + idx * 0.75;

    slide.addShape(pptx.ShapeType.rect, {
      x: 0.3, y: yPos, w: 4.7, h: 0.65,
      fill: { color: '7f1d1d' },
    });

    slide.addText(`❌ भ्रम: ${item[0]}`, {
      x: 0.4, y: yPos + 0.05, w: 4.5, h: 0.55,
      fontSize: 9, color: colors.lightGray,
      valign: 'middle',
    });

    slide.addShape(pptx.ShapeType.rect, {
      x: 5, y: yPos, w: 4.7, h: 0.65,
      fill: { color: '14532d' },
    });

    slide.addText(`✅ सच: ${item[1]}`, {
      x: 5.1, y: yPos + 0.05, w: 4.5, h: 0.55,
      fontSize: 9, color: colors.lightGray,
      valign: 'middle',
    });
  });

  // ============ SLIDE 9: Legal Framework ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('⚖️ कानूनी ढांचा (Legal Framework)', {
    x: 0.5, y: 0.3, w: 9, h: 0.5,
    fontSize: 26, color: colors.white, bold: true,
  });

  // THOA Act Box
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 0.3, y: 0.9, w: 4.7, h: 2.8,
    fill: { color: '1e3a5f' },
    line: { color: colors.blue, pt: 1 },
  });

  slide.addText('📜 THOA Act, 1994', {
    x: 0.5, y: 1, w: 4.3, h: 0.4,
    fontSize: 14, color: colors.blue, bold: true,
  });

  slide.addText('Transplantation of Human Organs & Tissues Act', {
    x: 0.5, y: 1.35, w: 4.3, h: 0.25,
    fontSize: 8, color: colors.darkGray,
  });

  const legalPoints = [
    '⚖️ भारत में मुख्य अंग प्रत्यारोपण कानून',
    '⚖️ 2011 और 2014 में संशोधित',
    '⚖️ अंग व्यापार पूरी तरह अवैध और दंडनीय',
    '⚖️ Brain Death को कानूनी मृत्यु की मान्यता',
    '⚖️ Living donor — केवल near relatives को',
    '⚖️ Authorization Committee की मंज़ूरी ज़रूरी',
  ];

  legalPoints.forEach((point, idx) => {
    slide.addText(point, {
      x: 0.5, y: 1.7 + idx * 0.3, w: 4.3, h: 0.3,
      fontSize: 9, color: colors.lightGray,
    });
  });

  // NOTTO Box
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 5.2, y: 0.9, w: 4.5, h: 1.5,
    fill: { color: '134e4a' },
    line: { color: colors.teal, pt: 1 },
  });

  slide.addText('🏛️ NOTTO & ROTTO', {
    x: 5.4, y: 1, w: 4.1, h: 0.35,
    fontSize: 13, color: colors.teal, bold: true,
  });

  slide.addText(
    'NOTTO: National Organ & Tissue Transplant Organisation\nराष्ट्रीय स्तर पर अंगदान की निगरानी और Waiting List manage करता है।\n\nROTTO/SOTTO: Regional & State Organisations',
    {
      x: 5.4, y: 1.35, w: 4.1, h: 1,
      fontSize: 8, color: colors.lightGray,
    }
  );

  // Penalties Box
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 5.2, y: 2.5, w: 4.5, h: 1.2,
    fill: { color: '78350f' },
    line: { color: colors.amber, pt: 1 },
  });

  slide.addText('⚠️ दंड (Penalties)', {
    x: 5.4, y: 2.6, w: 4.1, h: 0.35,
    fontSize: 12, color: colors.amber, bold: true,
  });

  slide.addText(
    '🚫 अंग व्यापार: 5-10 साल जेल + ₹20-1 करोड़ जुर्माना\n🚫 बिना मंज़ूरी अंग निकालना: 5 साल जेल\n🚫 फर्ज़ी दस्तावेज़: 10 साल तक जेल',
    {
      x: 5.4, y: 2.95, w: 4.1, h: 0.7,
      fontSize: 8, color: colors.lightGray,
    }
  );

  slide.addShape(pptx.ShapeType.roundRect, {
    x: 0.3, y: 3.85, w: 9.4, h: 0.5,
    fill: { color: '14532d' },
    line: { color: colors.emerald, pt: 1 },
  });

  slide.addText('🌐 Website: www.notto.gov.in | 📞 Helpline: 1800-11-4770 (Toll Free)', {
    x: 0.5, y: 3.95, w: 9, h: 0.3,
    fontSize: 12, color: colors.white, bold: true,
    align: 'center',
  });

  // ============ SLIDE 10: How to Register ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('अंगदाता कैसे बनें? (How to Register?)', {
    x: 0.5, y: 0.3, w: 9, h: 0.5,
    fontSize: 26, color: colors.white, bold: true,
  });

  slide.addText('It\'s FREE and takes only 2 minutes!', {
    x: 0.5, y: 0.75, w: 9, h: 0.3,
    fontSize: 12, color: colors.emerald,
  });

  const regSteps = [
    ['1', '🌐', 'NOTTO वेबसाइट पर जाएं', 'www.notto.gov.in पर जाएं', colors.teal],
    ['2', '📝', 'फॉर्म भरें', 'नाम, पता, Aadhaar, ब्लड ग्रुप भरें', colors.blue],
    ['3', '👨‍👩‍👧‍👦', 'परिवार को बताएं', 'अपने निर्णय के बारे में बताएं', colors.purple],
    ['4', '💳', 'Donor Card प्राप्त करें', 'रजिस्ट्रेशन के बाद Card मिलता है', colors.emerald],
    ['5', '📢', 'जागरूकता फैलाएं', 'दोस्तों को भी प्रेरित करें', colors.amber],
  ];

  regSteps.forEach((step, idx) => {
    slide.addShape(pptx.ShapeType.ellipse, {
      x: 0.5, y: 1.2 + idx * 0.7, w: 0.5, h: 0.5,
      fill: { color: step[4] },
    });

    slide.addText(step[0], {
      x: 0.5, y: 1.25 + idx * 0.7, w: 0.5, h: 0.4,
      fontSize: 14, color: colors.white, bold: true,
      align: 'center',
    });

    slide.addText(`${step[1]} ${step[2]}`, {
      x: 1.2, y: 1.2 + idx * 0.7, w: 3.5, h: 0.3,
      fontSize: 12, color: colors.white, bold: true,
    });

    slide.addText(step[3], {
      x: 1.2, y: 1.47 + idx * 0.7, w: 3.5, h: 0.25,
      fontSize: 9, color: colors.darkGray,
    });
  });

  // Who can donate box
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 5.2, y: 1.1, w: 4.5, h: 2.6,
    fill: { color: '134e4a' },
    line: { color: colors.teal, pt: 1 },
  });

  slide.addText('📋 कौन दान कर सकता है?', {
    x: 5.4, y: 1.2, w: 4.1, h: 0.4,
    fontSize: 13, color: colors.teal, bold: true,
  });

  const eligibility = [
    '✅ कोई भी व्यक्ति — उम्र, लिंग, जाति कोई बाधा नहीं',
    '✅ 18 वर्ष से कम — माता-पिता की सहमति से',
    '✅ बीमार लोग भी — डॉक्टर तय करेंगे',
    '✅ किसी भी धर्म के लोग दान कर सकते हैं',
    '❌ HIV/AIDS, Active Cancer वाले — कुछ अंग नहीं',
  ];

  eligibility.forEach((item, idx) => {
    slide.addText(item, {
      x: 5.4, y: 1.65 + idx * 0.38, w: 4.1, h: 0.35,
      fontSize: 9, color: colors.lightGray,
    });
  });

  slide.addShape(pptx.ShapeType.roundRect, {
    x: 5.2, y: 3.85, w: 4.5, h: 0.6,
    fill: { color: '14532d' },
    line: { color: colors.emerald, pt: 1 },
  });

  slide.addText('🆓 Registration FREE है!', {
    x: 5.4, y: 3.95, w: 4.1, h: 0.4,
    fontSize: 14, color: colors.white, bold: true,
    align: 'center',
  });

  // ============ SLIDE 11: Success Stories ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('सफलता की कहानियाँ (Success Stories) 🌟', {
    x: 0.5, y: 0.3, w: 9, h: 0.5,
    fontSize: 26, color: colors.white, bold: true,
  });

  const stories = [
    ['🏆', 'Tamil Nadu — भारत का Organ Donation Capital', '#1 in India', 'तमिलनाडु ने 2023 में सबसे ज़्यादा cadaveric donations किए।', colors.amber],
    ['🚑', 'Green Corridor — मुंबई से दिल्ली', '3 Hours', 'ट्रैफ़िक-फ़्री रूट से हार्ट 3 घंटे में पहुँचा!', '22c55e'],
    ['💚', 'एक Donor — 8 जिंदगियाँ', '8 Lives', 'एक व्यक्ति के अंगों से 8 लोगों को नया जीवन मिला।', colors.teal],
    ['👶', 'बच्चों को मिली नई ज़िंदगी', 'Living Donor', 'माँ ने अपने जिगर का हिस्सा बच्चे को दान किया।', 'ec4899'],
  ];

  stories.forEach((story, idx) => {
    const col = idx % 2;
    const row = Math.floor(idx / 2);

    slide.addShape(pptx.ShapeType.roundRect, {
      x: 0.3 + col * 4.9, y: 0.9 + row * 1.8, w: 4.7, h: 1.6,
      fill: { color: '1e293b' },
      line: { color: story[4], pt: 1 },
    });

    slide.addText(story[0], {
      x: 0.5 + col * 4.9, y: 1 + row * 1.8, w: 0.6, h: 0.5,
      fontSize: 28,
    });

    slide.addText(story[2], {
      x: 3.8 + col * 4.9, y: 1 + row * 1.8, w: 1, h: 0.35,
      fontSize: 9, color: story[4], bold: true,
      align: 'right',
    });

    slide.addText(story[1], {
      x: 1.1 + col * 4.9, y: 1.05 + row * 1.8, w: 3.5, h: 0.4,
      fontSize: 11, color: colors.white, bold: true,
    });

    slide.addText(story[3], {
      x: 0.5 + col * 4.9, y: 1.5 + row * 1.8, w: 4.3, h: 0.6,
      fontSize: 9, color: colors.lightGray,
    });
  });

  // ============ SLIDE 12: Pledge ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('❤️', {
    x: 4.25, y: 0.3, w: 1.5, h: 0.8,
    fontSize: 48, align: 'center',
  });

  slide.addText('अंगदान की शपथ (Pledge)', {
    x: 0.5, y: 1.2, w: 9, h: 0.5,
    fontSize: 28, color: colors.white, bold: true,
    align: 'center',
  });

  slide.addShape(pptx.ShapeType.roundRect, {
    x: 0.5, y: 1.85, w: 9, h: 2.4,
    fill: { color: '1e293b' },
    line: { color: '334155', pt: 1 },
  });

  slide.addText(
    '"मैं आज संकल्प लेता/लेती हूँ कि मैं अपनी मृत्यु के बाद अपने अंगों और ऊतकों को दान करूँगा/करूँगी, ताकि किसी जरूरतमंद व्यक्ति को नया जीवन मिल सके।\n\nमैं अपने परिवार को इस निर्णय के बारे में सूचित करूँगा/करूँगी और उन्हें भी अंगदान के लिए प्रेरित करूँगा/करूँगी।\n\nमैं समझता/समझती हूँ कि एक अंगदाता 8 जिंदगियाँ बचा सकता है और 75+ लोगों की ज़िंदगी सुधार सकता है।"',
    {
      x: 0.7, y: 2, w: 8.6, h: 2.1,
      fontSize: 12, color: colors.lightGray,
      align: 'center',
    }
  );

  slide.addText('"अंगदान — महादान"', {
    x: 0.5, y: 4.4, w: 9, h: 0.5,
    fontSize: 24, color: colors.teal, bold: true,
    align: 'center',
  });

  const pledgeOrgans = ['🫀 Heart', '🫁 Lungs', '🟤 Liver', '🫘 Kidneys', '👁️ Eyes', '🦴 Bones'];
  pledgeOrgans.forEach((organ, idx) => {
    slide.addShape(pptx.ShapeType.roundRect, {
      x: 0.5 + idx * 1.55, y: 5, w: 1.45, h: 0.45,
      fill: { color: '334155' },
      line: { color: '475569', pt: 1 },
    });

    slide.addText(organ, {
      x: 0.5 + idx * 1.55, y: 5.05, w: 1.45, h: 0.35,
      fontSize: 9, color: colors.white,
      align: 'center',
    });
  });

  // ============ SLIDE 13: Thank You ============
  slide = pptx.addSlide();
  slide.background = { color: colors.darkBg };

  slide.addText('❤️', {
    x: 4.25, y: 0.5, w: 1.5, h: 1,
    fontSize: 60, align: 'center',
  });

  slide.addText('धन्यवाद! 🙏', {
    x: 0.5, y: 1.7, w: 9, h: 0.7,
    fontSize: 48, color: colors.white, bold: true,
    align: 'center',
  });

  slide.addText('Thank You!', {
    x: 0.5, y: 2.4, w: 9, h: 0.5,
    fontSize: 28, color: colors.teal, bold: true,
    align: 'center',
  });

  slide.addText('"अंगदान — महादान" | "Donate Organs, Save Lives"', {
    x: 0.5, y: 3, w: 9, h: 0.4,
    fontSize: 14, color: colors.lightGray,
    align: 'center',
  });

  // Event details box
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 1, y: 3.5, w: 8, h: 1.4,
    fill: { color: '1e293b' },
    line: { color: '334155', pt: 1 },
  });

  const thankYouDetails = [
    ['🇮🇳 Programme:', 'अंगदान जीवन संजीवनी अभियान (NSS)'],
    ['📍 Venue:', 'TN Campus & Hargaon Village'],
    ['👤 Convener:', 'Dr. Rahul Kumar Pandey (Principal, TNACE)'],
    ['👥 Coordinator:', 'Dr. P.M. Jena Ma\'am (Asst. Prof., TSC)'],
  ];

  thankYouDetails.forEach((detail, idx) => {
    slide.addText(detail[0], {
      x: 1.2, y: 3.6 + idx * 0.3, w: 1.5, h: 0.28,
      fontSize: 9, color: colors.teal, bold: true,
    });
    slide.addText(detail[1], {
      x: 2.7, y: 3.6 + idx * 0.3, w: 5.8, h: 0.28,
      fontSize: 9, color: colors.lightGray,
    });
  });

  slide.addText('🌐 www.notto.gov.in | 📞 1800-11-4770', {
    x: 0.5, y: 5, w: 9, h: 0.35,
    fontSize: 12, color: colors.white,
    align: 'center',
  });

  slide.addText('"मृत्यु के बाद भी जीवन देना — यही सबसे बड़ा दान है" | "Not Me But You" — NSS Motto', {
    x: 0.5, y: 5.4, w: 9, h: 0.3,
    fontSize: 9, color: colors.darkGray,
    align: 'center',
  });

  // Generate and return blob
  try {
    const data = await pptx.write({ outputType: 'blob' });
    return { success: true, data };
  } catch (error) {
    console.error('PPT Generation Error:', error);
    return { success: false, error };
  }
}

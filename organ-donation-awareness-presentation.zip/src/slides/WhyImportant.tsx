import { motion } from 'framer-motion';

const reasons = [
  {
    emoji: '💀',
    title: 'हर दिन 20+ मरीज़ मर जाते हैं',
    titleEn: '20+ patients die daily waiting for organs',
    desc: 'भारत में हर दिन अंग न मिलने से 20 से ज़्यादा लोगों की मौत हो जाती है।',
    stat: '20+/day',
    color: 'from-red-600/30 to-red-800/20',
  },
  {
    emoji: '📉',
    title: 'बहुत कम दान दर',
    titleEn: 'Extremely low donation rate',
    desc: 'भारत में प्रति 10 लाख जनसंख्या पर केवल 0.52 अंगदान होते हैं जबकि स्पेन में 49.6!',
    stat: '0.52 pmp',
    color: 'from-amber-600/30 to-amber-800/20',
  },
  {
    emoji: '⏳',
    title: '5 लाख+ Waiting List',
    titleEn: '5 Lakh+ people on waiting list',
    desc: 'हर साल 5 लाख से ज़्यादा लोग अंग प्रत्यारोपण का इंतज़ार करते हैं। ज़्यादातर को कभी नहीं मिलता।',
    stat: '5,00,000+',
    color: 'from-orange-600/30 to-orange-800/20',
  },
  {
    emoji: '👁️',
    title: 'लाखों लोग अंधे हैं',
    titleEn: 'Millions are blind — cornea can help',
    desc: 'भारत में 12 लाख+ लोग कॉर्निया के इंतज़ार में हैं। मृत्यु के बाद आसानी से कॉर्निया दान हो सकता है।',
    stat: '12 Lakh+',
    color: 'from-cyan-600/30 to-cyan-800/20',
  },
  {
    emoji: '🫘',
    title: 'किडनी की सबसे ज़्यादा ज़रूरत',
    titleEn: 'Kidney has highest demand',
    desc: '2 लाख+ लोग हर साल किडनी का इंतज़ार करते हैं। केवल 10,000-12,000 को मिल पाती है।',
    stat: '2 Lakh+',
    color: 'from-purple-600/30 to-purple-800/20',
  },
  {
    emoji: '🌍',
    title: 'Organ Trafficking रोकें',
    titleEn: 'Stop illegal organ trade',
    desc: 'अंगदान की कमी से अवैध अंग तस्करी बढ़ती है। वैध दान से यह अपराध रुक सकता है।',
    stat: 'Stop Crime',
    color: 'from-slate-600/30 to-slate-800/20',
  },
];

export default function WhyImportant() {
  return (
    <div className="h-full w-full flex items-center justify-center overflow-y-auto p-6">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="mb-6"
        >
          <p className="text-teal-400 text-sm font-semibold tracking-wider uppercase">Slide 06</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            अंगदान क्यों ज़रूरी है? (Why is it Important?)
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {reasons.map((reason, idx) => (
            <motion.div
              key={idx}
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.15 * idx, type: 'spring' }}
              whileHover={{ scale: 1.03 }}
              className={`bg-gradient-to-br ${reason.color} rounded-xl p-4 border border-white/10 relative overflow-hidden`}
            >
              <motion.div
                className="absolute top-2 right-2 text-white/10 text-5xl font-black"
                animate={{ opacity: [0.05, 0.15, 0.05] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                {reason.stat}
              </motion.div>
              <div className="relative z-10">
                <motion.span
                  className="text-3xl block mb-2"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: idx * 0.3 }}
                >
                  {reason.emoji}
                </motion.span>
                <h4 className="text-white font-bold text-sm mb-1">{reason.title}</h4>
                <p className="text-white/40 text-xs italic mb-2">{reason.titleEn}</p>
                <p className="text-white/70 text-xs leading-relaxed">{reason.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Impact Visual */}
        <motion.div
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="mt-5 bg-gradient-to-r from-red-900/30 via-teal-900/30 to-emerald-900/30 rounded-xl p-5 border border-teal-400/20"
        >
          <div className="flex flex-wrap items-center justify-center gap-4 text-center">
            <div>
              <motion.p
                className="text-4xl font-black text-red-400"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                5,00,000+
              </motion.p>
              <p className="text-white/50 text-xs mt-1">Need Organs</p>
            </div>
            <span className="text-white/30 text-2xl">→</span>
            <div>
              <p className="text-4xl font-black text-amber-400">15,000</p>
              <p className="text-white/50 text-xs mt-1">Get Transplants</p>
            </div>
            <span className="text-white/30 text-2xl">→</span>
            <div>
              <motion.p
                className="text-4xl font-black text-emerald-400"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: 1 }}
              >
                97%
              </motion.p>
              <p className="text-white/50 text-xs mt-1">Die Waiting 😢</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

import { motion } from 'framer-motion';
import { Heart, Gift } from 'lucide-react';

export default function WhatIsOrganDonation() {
  const container = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.15 } },
  };
  const item = {
    hidden: { y: 30, opacity: 0 },
    show: { y: 0, opacity: 1 },
  };

  return (
    <div className="h-full w-full flex items-center justify-center overflow-y-auto p-6">
      <div className="max-w-5xl w-full">
        {/* Slide Title */}
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-red-500/20 rounded-xl flex items-center justify-center">
              <Heart className="w-6 h-6 text-red-400" />
            </div>
            <div>
              <p className="text-teal-400 text-sm font-semibold tracking-wider uppercase">Slide 02</p>
              <h2 className="text-3xl sm:text-4xl font-bold text-white">अंगदान क्या है? (What is Organ Donation?)</h2>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Left - Image & Definition */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <div className="rounded-2xl overflow-hidden mb-4 border border-white/10">
              <img
                src="/images/organ-donation-hero.jpg"
                alt="Organ Donation"
                className="w-full h-48 sm:h-56 object-cover"
              />
            </div>
            <div className="bg-gradient-to-br from-teal-900/50 to-emerald-900/50 rounded-2xl p-5 border border-teal-500/20">
              <h3 className="text-xl font-bold text-teal-300 mb-3 flex items-center gap-2">
                <Gift className="w-5 h-5" />
                परिभाषा (Definition)
              </h3>
              <p className="text-white/80 leading-relaxed text-sm">
                <strong className="text-white">अंगदान (Organ Donation)</strong> वह प्रक्रिया है जिसमें एक व्यक्ति
                अपने शरीर के स्वस्थ अंग (organs) या ऊतक (tissues) किसी जरूरतमंद मरीज़ को
                <strong className="text-teal-300"> प्रत्यारोपण (transplant)</strong> के लिए देता है।
              </p>
              <p className="text-white/70 leading-relaxed text-sm mt-2">
                यह <strong className="text-emerald-300">जीवित (Living)</strong> या{' '}
                <strong className="text-amber-300">मृत्यु के बाद (After Death)</strong> — दोनों तरीकों से हो सकता है।
              </p>
            </div>
          </motion.div>

          {/* Right - Key Points */}
          <motion.div variants={container} initial="hidden" animate="show" className="space-y-3">
            {[
              {
                emoji: '🫀',
                title: 'जीवन का उपहार',
                desc: 'अंगदान किसी इंसान को दिया जाने वाला सबसे बड़ा उपहार है — जीवन का उपहार।',
                descEn: 'Organ donation is the greatest gift one can give — the gift of life.',
                color: 'from-red-500/20 to-pink-500/20',
                border: 'border-red-500/30',
              },
              {
                emoji: '🏥',
                title: 'Transplantation Surgery',
                desc: 'डॉक्टर मरीज़ के खराब अंग को हटाकर, दान किए गए स्वस्थ अंग को लगाते हैं।',
                descEn: 'Doctors replace the failed organ with a healthy donated organ through surgery.',
                color: 'from-blue-500/20 to-cyan-500/20',
                border: 'border-blue-500/30',
              },
              {
                emoji: '8️⃣',
                title: '1 Donor = 8 Lives Saved',
                desc: 'एक अंगदाता 8 लोगों की जान बचा सकता है और 75+ लोगों की ज़िंदगी सुधार सकता है!',
                descEn: 'One organ donor can save up to 8 lives and improve 75+ lives through tissue donation!',
                color: 'from-emerald-500/20 to-green-500/20',
                border: 'border-emerald-500/30',
              },
              {
                emoji: '⏰',
                title: 'Waiting List Crisis',
                desc: 'भारत में हर साल 5 लाख+ लोग अंग प्रत्यारोपण का इंतज़ार करते हैं, लेकिन केवल ~15,000 को मिल पाता है।',
                descEn: 'In India, 5 lakh+ people wait for organ transplants annually, but only ~15,000 get them.',
                color: 'from-amber-500/20 to-orange-500/20',
                border: 'border-amber-500/30',
              },
              {
                emoji: '💡',
                title: 'जागरूकता की जरूरत',
                desc: 'अंगदान के बारे में जानकारी की कमी सबसे बड़ी बाधा है। जागरूकता ही समाधान है!',
                descEn: 'Lack of awareness about organ donation is the biggest barrier. Awareness is the solution!',
                color: 'from-purple-500/20 to-violet-500/20',
                border: 'border-purple-500/30',
              },
            ].map((point, idx) => (
              <motion.div
                key={idx}
                variants={item}
                className={`bg-gradient-to-r ${point.color} rounded-xl p-4 border ${point.border} hover:scale-[1.02] transition-transform`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">{point.emoji}</span>
                  <div>
                    <h4 className="text-white font-bold text-sm">{point.title}</h4>
                    <p className="text-white/70 text-xs mt-1">{point.desc}</p>
                    <p className="text-white/50 text-xs mt-0.5 italic">{point.descEn}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </div>
  );
}

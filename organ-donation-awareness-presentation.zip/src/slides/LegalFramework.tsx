import { motion } from 'framer-motion';
import { Shield } from 'lucide-react';

export default function LegalFramework() {
  return (
    <div className="h-full w-full flex items-center justify-center overflow-y-auto p-6">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="mb-5"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
              <Shield className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-teal-400 text-sm font-semibold tracking-wider uppercase">Slide 09</p>
              <h2 className="text-3xl sm:text-4xl font-bold text-white">
                कानूनी ढांचा (Legal Framework)
              </h2>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-5">
          {/* Main Act */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-blue-900/40 to-indigo-900/30 rounded-2xl p-5 border border-blue-400/20"
          >
            <h3 className="text-xl font-bold text-blue-300 mb-3">📜 THOA Act, 1994</h3>
            <p className="text-white/60 text-xs italic mb-3">
              Transplantation of Human Organs & Tissues Act
            </p>
            <div className="space-y-2">
              {[
                'भारत में अंग प्रत्यारोपण को नियंत्रित करने वाला मुख्य कानून',
                '2011 और 2014 में संशोधित किया गया',
                'अंग व्यापार (organ trade) पूरी तरह अवैध और दंडनीय',
                'Brain Death को कानूनी मृत्यु के रूप में मान्यता',
                'Living donor — केवल near relatives को दान कर सकते हैं',
                'Authorization Committee की मंज़ूरी ज़रूरी',
              ].map((point, idx) => (
                <motion.div
                  key={idx}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.5 + idx * 0.1 }}
                  className="flex items-start gap-2 text-sm text-white/80"
                >
                  <span className="text-blue-400 mt-0.5">⚖️</span>
                  <span>{point}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Organizations */}
          <div className="space-y-4">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="bg-gradient-to-br from-teal-900/40 to-emerald-900/30 rounded-2xl p-5 border border-teal-400/20"
            >
              <h3 className="text-lg font-bold text-teal-300 mb-3">🏛️ NOTTO & ROTTO</h3>
              <div className="space-y-3">
                <div className="bg-white/5 rounded-lg p-3">
                  <h4 className="text-white font-bold text-sm">NOTTO</h4>
                  <p className="text-white/50 text-xs">National Organ & Tissue Transplant Organisation</p>
                  <p className="text-white/70 text-xs mt-1">
                    राष्ट्रीय स्तर पर अंगदान और प्रत्यारोपण की निगरानी करता है। Waiting list manage करता है।
                  </p>
                </div>
                <div className="bg-white/5 rounded-lg p-3">
                  <h4 className="text-white font-bold text-sm">ROTTO & SOTTO</h4>
                  <p className="text-white/50 text-xs">Regional & State Organ Transplant Organisations</p>
                  <p className="text-white/70 text-xs mt-1">
                    राज्य स्तर पर अंगदान कार्यक्रम चलाते हैं। हर राज्य का अपना SOTTO होता है।
                  </p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="bg-gradient-to-br from-amber-900/40 to-orange-900/30 rounded-2xl p-5 border border-amber-400/20"
            >
              <h3 className="text-lg font-bold text-amber-300 mb-2">⚠️ दंड (Penalties)</h3>
              <div className="space-y-2">
                {[
                  'अंग व्यापार: 5-10 साल की जेल + ₹20-1 करोड़ जुर्माना',
                  'बिना मंज़ूरी अंग निकालना: 5 साल की जेल',
                  'फर्ज़ी दस्तावेज़ बनाना: 10 साल तक की जेल',
                ].map((point, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-sm text-white/80">
                    <span className="text-amber-400">🚫</span>
                    <span>{point}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>

        {/* Bottom Note */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-4 bg-emerald-900/20 rounded-xl p-3 border border-emerald-400/20 text-center"
        >
          <p className="text-emerald-200 text-sm font-semibold">
            🌐 Website: <span className="text-white underline">www.notto.gov.in</span> | 
            📞 Helpline: <span className="text-white">1800-11-4770</span> (Toll Free)
          </p>
        </motion.div>
      </div>
    </div>
  );
}

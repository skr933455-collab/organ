import { motion } from 'framer-motion';

const countryData = [
  { country: '🇪🇸 Spain', rate: 49.6, bar: 'w-full', color: 'bg-emerald-500' },
  { country: '🇺🇸 USA', rate: 41.8, bar: 'w-[84%]', color: 'bg-blue-500' },
  { country: '🇫🇷 France', rate: 33.0, bar: 'w-[66%]', color: 'bg-indigo-500' },
  { country: '🇬🇧 UK', rate: 23.0, bar: 'w-[46%]', color: 'bg-purple-500' },
  { country: '🇧🇷 Brazil', rate: 17.0, bar: 'w-[34%]', color: 'bg-amber-500' },
  { country: '🇮🇳 India', rate: 0.52, bar: 'w-[3%]', color: 'bg-red-500' },
];

const indiaData = [
  { label: 'किडनी की ज़रूरत', need: '2,00,000+', available: '10,000-12,000', gap: '95%', emoji: '🫘' },
  { label: 'लिवर की ज़रूरत', need: '50,000+', available: '3,500', gap: '93%', emoji: '🟤' },
  { label: 'हार्ट की ज़रूरत', need: '50,000+', available: '250-300', gap: '99%', emoji: '🫀' },
  { label: 'कॉर्निया की ज़रूरत', need: '12,00,000+', available: '50,000', gap: '96%', emoji: '👁️' },
];

export default function IndiaStats() {
  return (
    <div className="h-full w-full flex items-center justify-center overflow-y-auto p-6">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="mb-5"
        >
          <p className="text-teal-400 text-sm font-semibold tracking-wider uppercase">Slide 07</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            भारत का Data (India's Organ Donation Statistics)
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-5">
          {/* Global Comparison */}
          <motion.div
            initial={{ x: -60, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-white/5 rounded-2xl p-5 border border-white/10"
          >
            <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
              🌍 वैश्विक तुलना (Global Comparison)
              <span className="text-xs text-white/40 font-normal">per million population</span>
            </h3>
            <div className="space-y-2.5">
              {countryData.map((c, idx) => (
                <div key={idx}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-white/80 text-xs font-medium">{c.country}</span>
                    <span className={`text-xs font-bold ${c.country.includes('India') ? 'text-red-400' : 'text-white/60'}`}>
                      {c.rate} pmp
                    </span>
                  </div>
                  <div className="h-3 bg-white/5 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: c.bar.replace('w-', '').replace('[', '').replace(']', '') }}
                      transition={{ delay: 0.5 + idx * 0.15, duration: 1, ease: 'easeOut' }}
                      className={`h-full ${c.color} rounded-full ${c.country.includes('India') ? 'animate-pulse' : ''}`}
                      style={{ width: c.country.includes('India') ? '3%' : undefined }}
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3 bg-red-500/10 rounded-lg p-2 border border-red-500/20">
              <p className="text-red-300 text-xs text-center font-semibold">
                😰 भारत दुनिया में सबसे कम अंगदान दर वाले देशों में से एक है!
              </p>
            </div>
          </motion.div>

          {/* India Organ-wise Gap */}
          <motion.div
            initial={{ x: 60, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="bg-white/5 rounded-2xl p-5 border border-white/10"
          >
            <h3 className="text-lg font-bold text-white mb-3">
              🇮🇳 भारत में अंग-वार कमी (Organ-wise Gap)
            </h3>
            <div className="space-y-3">
              {indiaData.map((organ, idx) => (
                <motion.div
                  key={idx}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.7 + idx * 0.15 }}
                  className="bg-white/5 rounded-xl p-3 border border-white/5"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xl">{organ.emoji}</span>
                    <span className="text-white font-bold text-sm">{organ.label}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="bg-red-500/10 rounded-lg p-1.5">
                      <p className="text-red-300 text-xs font-bold">{organ.need}</p>
                      <p className="text-white/40 text-xs">ज़रूरत</p>
                    </div>
                    <div className="bg-emerald-500/10 rounded-lg p-1.5">
                      <p className="text-emerald-300 text-xs font-bold">{organ.available}</p>
                      <p className="text-white/40 text-xs">उपलब्ध</p>
                    </div>
                    <div className="bg-amber-500/10 rounded-lg p-1.5">
                      <p className="text-amber-300 text-xs font-bold">{organ.gap} Gap</p>
                      <p className="text-white/40 text-xs">कमी</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Bottom Stats Bar */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3"
        >
          {[
            { label: 'Registered Donors', value: '4.5 Lakh+', emoji: '📝', color: 'border-teal-500/30' },
            { label: 'Deceased Donors (2023)', value: '1,028', emoji: '💙', color: 'border-blue-500/30' },
            { label: 'Top State', value: 'Tamil Nadu', emoji: '🏆', color: 'border-amber-500/30' },
            { label: 'NOTTO Helpline', value: '1800-11-4770', emoji: '📞', color: 'border-green-500/30' },
          ].map((stat, idx) => (
            <motion.div
              key={idx}
              whileHover={{ scale: 1.05 }}
              className={`bg-white/5 rounded-xl p-3 border ${stat.color} text-center`}
            >
              <span className="text-xl">{stat.emoji}</span>
              <p className="text-white font-bold text-sm mt-1">{stat.value}</p>
              <p className="text-white/40 text-xs">{stat.label}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}

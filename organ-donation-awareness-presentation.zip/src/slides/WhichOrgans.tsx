import { motion } from 'framer-motion';

const organs = [
  { emoji: '🫀', name: 'Heart (हृदय)', info: 'हृदय रोगियों को नया जीवन', time: '4-6 hours', color: 'from-red-500/30 to-red-600/20', border: 'border-red-400/40' },
  { emoji: '🫁', name: 'Lungs (फेफड़े)', info: 'श्वसन विफलता के मरीज़ों के लिए', time: '6-8 hours', color: 'from-blue-500/30 to-blue-600/20', border: 'border-blue-400/40' },
  { emoji: '🟤', name: 'Liver (यकृत)', info: 'जिगर की बीमारी से पीड़ित लोगों के लिए', time: '12-15 hours', color: 'from-amber-600/30 to-amber-700/20', border: 'border-amber-400/40' },
  { emoji: '🫘', name: 'Kidneys (गुर्दे)', info: 'किडनी फेलियर के मरीज़ — सबसे ज़्यादा माँग', time: '24-48 hours', color: 'from-orange-500/30 to-orange-600/20', border: 'border-orange-400/40' },
  { emoji: '🟡', name: 'Pancreas (अग्न्याशय)', info: 'डायबिटीज़ के गंभीर मरीज़ों के लिए', time: '12-24 hours', color: 'from-yellow-500/30 to-yellow-600/20', border: 'border-yellow-400/40' },
  { emoji: '🔵', name: 'Intestines (आंतें)', info: 'आंतों की बीमारी के मरीज़ों के लिए', time: '8-12 hours', color: 'from-indigo-500/30 to-indigo-600/20', border: 'border-indigo-400/40' },
  { emoji: '👁️', name: 'Cornea (कॉर्निया)', info: 'अंधेपन को दूर करता है — सबसे आसान दान', time: '14 days', color: 'from-cyan-500/30 to-cyan-600/20', border: 'border-cyan-400/40' },
  { emoji: '🦴', name: 'Bones (हड्डियाँ)', info: 'हड्डी की बीमारी/फ्रैक्चर में मदद', time: '5 years stored', color: 'from-slate-400/30 to-slate-500/20', border: 'border-slate-400/40' },
  { emoji: '🩸', name: 'Bone Marrow (अस्थि मज्जा)', info: 'ब्लड कैंसर/ल्यूकीमिया के मरीज़ों के लिए', time: 'Living Donor', color: 'from-rose-500/30 to-rose-600/20', border: 'border-rose-400/40' },
  { emoji: '🟠', name: 'Skin (त्वचा)', info: 'जले हुए मरीज़ों की मदद', time: '5 years stored', color: 'from-pink-500/30 to-pink-600/20', border: 'border-pink-400/40' },
  { emoji: '❤️', name: 'Heart Valves (हार्ट वाल्व)', info: 'वाल्व रिप्लेसमेंट सर्जरी के लिए', time: '10 years stored', color: 'from-fuchsia-500/30 to-fuchsia-600/20', border: 'border-fuchsia-400/40' },
  { emoji: '🩹', name: 'Tendons (कण्डरा)', info: 'जोड़ों की सर्जरी में उपयोग', time: '5 years stored', color: 'from-emerald-500/30 to-emerald-600/20', border: 'border-emerald-400/40' },
];

export default function WhichOrgans() {
  return (
    <div className="h-full w-full flex items-center justify-center overflow-y-auto p-6">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="mb-6"
        >
          <p className="text-teal-400 text-sm font-semibold tracking-wider uppercase">Slide 03</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            कौन-कौन से अंग दान किए जा सकते हैं?
          </h2>
          <p className="text-white/60 mt-1">Which organs & tissues can be donated?</p>
        </motion.div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {organs.map((organ, idx) => (
            <motion.div
              key={idx}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1 * idx, type: 'spring', stiffness: 200 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className={`bg-gradient-to-br ${organ.color} rounded-xl p-3 border ${organ.border} cursor-pointer`}
            >
              <motion.span
                className="text-3xl block mb-2"
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: idx * 0.3 }}
              >
                {organ.emoji}
              </motion.span>
              <h4 className="text-white font-bold text-xs sm:text-sm">{organ.name}</h4>
              <p className="text-white/60 text-xs mt-1">{organ.info}</p>
              <div className="mt-2 inline-block bg-black/30 rounded-full px-2 py-0.5">
                <span className="text-teal-300 text-xs">⏱ {organ.time}</span>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="mt-4 bg-gradient-to-r from-teal-600/20 to-emerald-600/20 rounded-xl p-4 border border-teal-400/20 text-center"
        >
          <p className="text-teal-200 font-semibold text-sm">
            💡 एक अंगदाता <span className="text-white text-lg font-bold">8 जिंदगियाँ</span> बचा सकता है
            और <span className="text-white text-lg font-bold">75+</span> लोगों की ज़िंदगी सुधार सकता है!
          </p>
        </motion.div>
      </div>
    </div>
  );
}

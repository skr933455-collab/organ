import { motion } from 'framer-motion';

const stories = [
  {
    title: 'Tamil Nadu — भारत का Organ Donation Capital',
    emoji: '🏆',
    desc: 'तमिलनाडु ने 2023 में सबसे ज़्यादा cadaveric organ donations किए। सरकार की सक्रिय नीतियों और जागरूकता अभियानों ने इसे संभव किया।',
    stat: '#1 in India',
    color: 'from-amber-600/30 to-amber-800/20',
    border: 'border-amber-400/30',
  },
  {
    title: 'Green Corridor — मुंबई से दिल्ली',
    emoji: '🚑',
    desc: 'ट्रैफ़िक-फ़्री Green Corridor बनाकर अंगों को record time में एक शहर से दूसरे शहर पहुँचाया जाता है। मुंबई से दिल्ली तक हार्ट 3 घंटे में पहुँचा!',
    stat: '3 Hours',
    color: 'from-green-600/30 to-green-800/20',
    border: 'border-green-400/30',
  },
  {
    title: 'एक Donor — 8 जिंदगियाँ',
    emoji: '💚',
    desc: 'चेन्नई के एक 35 वर्षीय व्यक्ति की brain death के बाद, उसके heart, 2 kidneys, liver, 2 lungs, और 2 corneas — कुल 8 लोगों को नया जीवन मिला।',
    stat: '8 Lives Saved',
    color: 'from-teal-600/30 to-teal-800/20',
    border: 'border-teal-400/30',
  },
  {
    title: 'बच्चों को मिली नई ज़िंदगी',
    emoji: '👶',
    desc: 'AIIMS दिल्ली में सफल pediatric liver transplant — एक माँ ने अपने जिगर का हिस्सा अपने 2 साल के बच्चे को दान किया। दोनों स्वस्थ हैं।',
    stat: 'Living Donor',
    color: 'from-pink-600/30 to-pink-800/20',
    border: 'border-pink-400/30',
  },
];

export default function SuccessStories() {
  return (
    <div className="h-full w-full flex items-center justify-center overflow-y-auto p-6">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="mb-6"
        >
          <p className="text-teal-400 text-sm font-semibold tracking-wider uppercase">Slide 11</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            सफलता की कहानियाँ (Success Stories) 🌟
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-4">
          {stories.map((story, idx) => (
            <motion.div
              key={idx}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2 + idx * 0.2, type: 'spring' }}
              whileHover={{ scale: 1.03 }}
              className={`bg-gradient-to-br ${story.color} rounded-2xl p-5 border ${story.border} relative overflow-hidden`}
            >
              <motion.div
                className="absolute top-3 right-3 bg-white/10 rounded-full px-3 py-1"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <span className="text-white font-bold text-xs">{story.stat}</span>
              </motion.div>
              <motion.span
                className="text-4xl block mb-3"
                animate={{ y: [0, -5, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: idx * 0.3 }}
              >
                {story.emoji}
              </motion.span>
              <h3 className="text-white font-bold text-base mb-2 pr-16">{story.title}</h3>
              <p className="text-white/70 text-sm leading-relaxed">{story.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Image */}
        <motion.div
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="mt-5 grid grid-cols-2 gap-3"
        >
          <div className="rounded-xl overflow-hidden border border-white/10">
            <img
              src="https://images.pexels.com/photos/24193884/pexels-photo-24193884.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
              alt="Surgery"
              className="w-full h-36 object-cover"
            />
          </div>
          <div className="rounded-xl overflow-hidden border border-white/10">
            <img
              src="https://images.pexels.com/photos/6129035/pexels-photo-6129035.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
              alt="Hospital Care"
              className="w-full h-36 object-cover"
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
}

import { motion } from 'framer-motion';
import { Heart, Phone, Globe, Users, User } from 'lucide-react';

export default function ThankYouSlide() {
  return (
    <div className="h-full w-full relative flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-teal-900 via-slate-900 to-emerald-900" />

      {/* Animated circles */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full border border-teal-400/10"
          animate={{
            scale: [1, 2, 3],
            opacity: [0.3, 0.1, 0],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            delay: i * 0.8,
          }}
          style={{
            width: 100,
            height: 100,
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
          }}
        />
      ))}

      <div className="relative z-10 text-center px-6 max-w-3xl">
        {/* Animated Heart */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', delay: 0.2 }}
          className="mb-6"
        >
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="inline-flex items-center justify-center w-28 h-28 bg-gradient-to-br from-red-500/30 to-pink-500/30 rounded-full border-2 border-red-400/40"
          >
            <Heart className="w-16 h-16 text-red-400" fill="currentColor" />
          </motion.div>
        </motion.div>

        <motion.h1
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-4xl sm:text-6xl font-extrabold text-white mb-3"
        >
          धन्यवाद! 🙏
        </motion.h1>

        <motion.p
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-teal-300 to-emerald-300 bg-clip-text text-transparent mb-6"
        >
          Thank You!
        </motion.p>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="text-lg text-white/70 mb-8"
        >
          "अंगदान — महादान" | "Donate Organs, Save Lives"
        </motion.p>

        {/* Event Details */}
        <motion.div
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.1 }}
          className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 mb-6"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-teal-500/20 rounded-lg flex items-center justify-center">
                <span className="text-lg">🇮🇳</span>
              </div>
              <div>
                <p className="text-white/50 text-xs">Programme</p>
                <p className="text-white font-semibold text-sm">
                  अंगदान जीवन संजीवनी अभियान (NSS)
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center">
                <span className="text-lg">📍</span>
              </div>
              <div>
                <p className="text-white/50 text-xs">Venue</p>
                <p className="text-white font-semibold text-sm">TN Campus & Hargaon Village</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <User className="w-10 h-10 p-2 bg-amber-500/20 rounded-lg text-amber-300" />
              <div>
                <p className="text-white/50 text-xs">Convener</p>
                <p className="text-white font-semibold text-sm">Dr. Rahul Kumar Pandey</p>
                <p className="text-white/40 text-xs">Principal, TNACE</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Users className="w-10 h-10 p-2 bg-pink-500/20 rounded-lg text-pink-300" />
              <div>
                <p className="text-white/50 text-xs">Coordinator</p>
                <p className="text-white font-semibold text-sm">Dr. P.M. Jena Ma'am</p>
                <p className="text-white/40 text-xs">Asst. Professor, TSC</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Contact Info */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.3 }}
          className="flex flex-wrap justify-center gap-4"
        >
          <div className="flex items-center gap-2 bg-white/5 rounded-full px-4 py-2 border border-white/10">
            <Globe className="w-4 h-4 text-teal-300" />
            <span className="text-white/70 text-sm">www.notto.gov.in</span>
          </div>
          <div className="flex items-center gap-2 bg-white/5 rounded-full px-4 py-2 border border-white/10">
            <Phone className="w-4 h-4 text-green-300" />
            <span className="text-white/70 text-sm">1800-11-4770</span>
          </div>
        </motion.div>

        {/* Bottom Quote */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.8 }}
          className="mt-6 text-white/40 text-xs italic"
        >
          "मृत्यु के बाद भी जीवन देना — यही सबसे बड़ा दान है" | "Not Me But You" — NSS Motto
        </motion.p>
      </div>
    </div>
  );
}

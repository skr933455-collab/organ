import { motion } from 'framer-motion';

const mythsFacts = [
  {
    myth: 'अंगदान धर्म के विरुद्ध है',
    mythEn: 'Organ donation is against religion',
    fact: 'सभी प्रमुख धर्म — हिंदू, मुस्लिम, ईसाई, सिख — अंगदान का समर्थन करते हैं। यह सबसे बड़ा दान (महादान) माना जाता है।',
    factEn: 'All major religions support organ donation. It is considered the greatest charity.',
  },
  {
    myth: 'अगर डॉक्टर को पता चले कि मैं donor हूँ तो वो मेरा इलाज ठीक से नहीं करेंगे',
    mythEn: 'Doctors won\'t treat me properly if they know I\'m a donor',
    fact: 'डॉक्टर की पहली प्राथमिकता हमेशा मरीज़ की जान बचाना है। अंगदान तभी होता है जब Brain Death हो जाए।',
    factEn: 'Doctor\'s first priority is always saving the patient. Donation only happens after brain death.',
  },
  {
    myth: 'बूढ़े लोग अंगदान नहीं कर सकते',
    mythEn: 'Old people can\'t donate organs',
    fact: 'उम्र कोई बाधा नहीं! 85+ साल के लोगों ने भी सफलतापूर्वक अंगदान किया है। अंगों की स्वास्थ्य स्थिति मायने रखती है, उम्र नहीं।',
    factEn: 'Age is no barrier! People 85+ have successfully donated. Organ health matters, not age.',
  },
  {
    myth: 'अंगदान से शरीर बिगड़ जाता है — अंतिम संस्कार नहीं हो सकता',
    mythEn: 'Body gets disfigured — last rites can\'t be performed',
    fact: 'सर्जरी बहुत सावधानी से होती है। शरीर को पूरे सम्मान से वापस किया जाता है। सामान्य अंतिम संस्कार हो सकता है।',
    factEn: 'Surgery is done very carefully. Body is returned respectfully. Normal last rites can be performed.',
  },
  {
    myth: 'केवल अमीर लोगों को ही अंग मिलते हैं',
    mythEn: 'Only rich people get organs',
    fact: 'NOTTO कंप्यूटर सिस्टम से मिलान होता है — ज़रूरत, blood group, और waiting time के आधार पर। कोई भेदभाव नहीं।',
    factEn: 'NOTTO computer matching is based on need, blood group, waiting time. No discrimination.',
  },
  {
    myth: 'अंगदान से दाता के परिवार को पैसे देने पड़ते हैं',
    mythEn: 'Donor family has to pay money',
    fact: 'अंगदान पूरी तरह नि:शुल्क है! अंग प्राप्तकर्ता या अस्पताल सारा खर्च वहन करता है।',
    factEn: 'Organ donation is completely free! Recipient or hospital bears all costs.',
  },
];

export default function MythsFacts() {
  return (
    <div className="h-full w-full flex items-center justify-center overflow-y-auto p-6">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="mb-5"
        >
          <p className="text-teal-400 text-sm font-semibold tracking-wider uppercase">Slide 08</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            भ्रम vs सच्चाई (Myths vs Facts)
          </h2>
          <p className="text-white/50 text-sm mt-1">Common misconceptions about organ donation</p>
        </motion.div>

        <div className="space-y-3">
          {mythsFacts.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ x: idx % 2 === 0 ? -80 : 80, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.15 * idx, type: 'spring', stiffness: 120 }}
              className="bg-white/5 rounded-xl border border-white/10 overflow-hidden"
            >
              <div className="grid md:grid-cols-2">
                {/* Myth */}
                <div className="bg-red-900/20 p-3 border-b md:border-b-0 md:border-r border-red-500/20">
                  <div className="flex items-start gap-2">
                    <motion.span
                      className="text-xl"
                      animate={{ rotate: [0, 15, -15, 0] }}
                      transition={{ duration: 2, repeat: Infinity, delay: idx * 0.3 }}
                    >
                      ❌
                    </motion.span>
                    <div>
                      <p className="text-red-300 text-xs font-bold uppercase tracking-wider mb-1">भ्रम (Myth)</p>
                      <p className="text-white/80 text-sm font-medium">{item.myth}</p>
                      <p className="text-white/40 text-xs italic mt-0.5">{item.mythEn}</p>
                    </div>
                  </div>
                </div>
                {/* Fact */}
                <div className="bg-emerald-900/20 p-3">
                  <div className="flex items-start gap-2">
                    <motion.span
                      className="text-xl"
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity, delay: idx * 0.3 }}
                    >
                      ✅
                    </motion.span>
                    <div>
                      <p className="text-emerald-300 text-xs font-bold uppercase tracking-wider mb-1">सच्चाई (Fact)</p>
                      <p className="text-white/80 text-sm">{item.fact}</p>
                      <p className="text-white/40 text-xs italic mt-0.5">{item.factEn}</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

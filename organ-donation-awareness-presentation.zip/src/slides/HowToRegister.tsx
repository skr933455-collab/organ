import { motion } from 'framer-motion';

const steps = [
  {
    num: '1',
    title: 'NOTTO वेबसाइट पर जाएं',
    titleEn: 'Visit NOTTO Website',
    desc: 'www.notto.gov.in पर जाएं और "Pledge to Donate" पर क्लिक करें',
    icon: '🌐',
    color: 'from-teal-500 to-teal-600',
  },
  {
    num: '2',
    title: 'फॉर्म भरें',
    titleEn: 'Fill the Registration Form',
    desc: 'अपना नाम, पता, Aadhaar/ID, ब्लड ग्रुप, और कौन से अंग दान करना चाहते हैं — भरें',
    icon: '📝',
    color: 'from-blue-500 to-blue-600',
  },
  {
    num: '3',
    title: 'परिवार को बताएं',
    titleEn: 'Inform Your Family',
    desc: 'अपने निर्णय के बारे में परिवार से बात करें। उनकी सहमति बहुत ज़रूरी है।',
    icon: '👨‍👩‍👧‍👦',
    color: 'from-purple-500 to-purple-600',
  },
  {
    num: '4',
    title: 'Donor Card प्राप्त करें',
    titleEn: 'Receive Donor Card',
    desc: 'रजिस्ट्रेशन के बाद आपको Donor Card मिलता है — इसे अपने साथ रखें',
    icon: '💳',
    color: 'from-emerald-500 to-emerald-600',
  },
  {
    num: '5',
    title: 'जागरूकता फैलाएं',
    titleEn: 'Spread Awareness',
    desc: 'अपने दोस्तों, रिश्तेदारों को भी अंगदान के बारे में बताएं और प्रेरित करें',
    icon: '📢',
    color: 'from-amber-500 to-amber-600',
  },
];

export default function HowToRegister() {
  return (
    <div className="h-full w-full flex items-center justify-center overflow-y-auto p-6">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="mb-6"
        >
          <p className="text-teal-400 text-sm font-semibold tracking-wider uppercase">Slide 10</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            अंगदाता कैसे बनें? (How to Register?)
          </h2>
          <p className="text-white/50 text-sm mt-1">It's FREE and takes only 2 minutes!</p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Steps */}
          <div className="space-y-3">
            {steps.map((step, idx) => (
              <motion.div
                key={idx}
                initial={{ x: -60, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.2 + idx * 0.15, type: 'spring' }}
                className="flex items-start gap-3 bg-white/5 rounded-xl p-3 border border-white/10 hover:bg-white/10 transition-colors"
              >
                <motion.div
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.5 }}
                  className={`bg-gradient-to-br ${step.color} w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0 shadow-lg`}
                >
                  {step.num}
                </motion.div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{step.icon}</span>
                    <h4 className="text-white font-bold text-sm">{step.title}</h4>
                  </div>
                  <p className="text-white/40 text-xs">{step.titleEn}</p>
                  <p className="text-white/70 text-xs mt-1">{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Right Side - Important Info */}
          <div className="space-y-4">
            <motion.div
              initial={{ x: 60, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="rounded-2xl overflow-hidden border border-white/10"
            >
              <img
                src="https://images.pexels.com/photos/14558557/pexels-photo-14558557.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
                alt="Doctor and patient"
                className="w-full h-40 object-cover"
              />
            </motion.div>

            <motion.div
              initial={{ x: 60, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="bg-gradient-to-br from-teal-900/50 to-emerald-900/30 rounded-2xl p-5 border border-teal-400/20"
            >
              <h3 className="text-lg font-bold text-teal-300 mb-3">📋 कौन दान कर सकता है?</h3>
              <div className="space-y-2">
                {[
                  '✅ कोई भी व्यक्ति — उम्र, लिंग, जाति कोई बाधा नहीं',
                  '✅ 18 वर्ष से कम — माता-पिता की सहमति से',
                  '✅ बीमार लोग भी — डॉक्टर तय करेंगे कौन से अंग दान हो सकते हैं',
                  '✅ किसी भी धर्म के लोग दान कर सकते हैं',
                  '❌ HIV/AIDS, Active Cancer वाले — कुछ अंग दान नहीं कर सकते',
                ].map((point, idx) => (
                  <p key={idx} className="text-white/80 text-xs">{point}</p>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ x: 60, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.9 }}
              className="bg-gradient-to-r from-green-600/20 to-emerald-600/20 rounded-xl p-4 border border-green-400/30 text-center"
            >
              <motion.p
                className="text-green-300 font-bold text-lg"
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                🆓 Registration FREE है!
              </motion.p>
              <p className="text-white/60 text-xs mt-1">
                www.notto.gov.in | 1800-11-4770
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

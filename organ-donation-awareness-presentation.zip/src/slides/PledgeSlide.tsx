import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

export default function PledgeSlide() {
  return (
    <div className="h-full w-full relative flex items-center justify-center overflow-y-auto p-6">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url('/images/pledge-hands.jpg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-teal-900/90 via-slate-900/85 to-emerald-900/90" />

      {/* Floating Hearts */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute text-red-400/20"
          animate={{
            y: [0, -150, 0],
            opacity: [0, 0.8, 0],
          }}
          transition={{
            duration: 4 + Math.random() * 3,
            repeat: Infinity,
            delay: Math.random() * 4,
          }}
          style={{
            left: `${Math.random() * 100}%`,
            top: `${60 + Math.random() * 30}%`,
            fontSize: `${16 + Math.random() * 24}px`,
          }}
        >
          ❤️
        </motion.div>
      ))}

      <div className="relative z-10 max-w-3xl w-full text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', delay: 0.2 }}
          className="mb-6"
        >
          <motion.div
            animate={{ scale: [1, 1.15, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="inline-flex items-center justify-center w-24 h-24 bg-red-500/20 rounded-full border-2 border-red-400/40"
          >
            <Heart className="w-14 h-14 text-red-400" fill="currentColor" />
          </motion.div>
        </motion.div>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-teal-400 text-sm font-semibold tracking-wider uppercase mb-3"
        >
          Slide 12 — शपथ / Pledge
        </motion.p>

        <motion.h2
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-3xl sm:text-4xl font-bold text-white mb-6"
        >
          अंगदान की शपथ
        </motion.h2>

        <motion.div
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="bg-white/10 backdrop-blur-md rounded-2xl p-6 sm:p-8 border border-white/20 text-left"
        >
          <div className="space-y-4 text-white/90 text-sm sm:text-base leading-relaxed">
            <motion.p
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.9 }}
            >
              <span className="text-teal-300 font-bold">"</span>
              मैं आज संकल्प लेता/लेती हूँ कि मैं अपनी मृत्यु के बाद अपने अंगों और ऊतकों को दान करूँगा/करूँगी,
              ताकि किसी जरूरतमंद व्यक्ति को नया जीवन मिल सके।
            </motion.p>
            <motion.p
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 1.1 }}
            >
              मैं अपने परिवार को इस निर्णय के बारे में सूचित करूँगा/करूँगी और उन्हें भी अंगदान के लिए प्रेरित करूँगा/करूँगी।
            </motion.p>
            <motion.p
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 1.3 }}
            >
              मैं समझता/समझती हूँ कि एक अंगदाता <strong className="text-teal-300">8 जिंदगियाँ</strong> बचा सकता है
              और <strong className="text-teal-300">75+ लोगों</strong> की ज़िंदगी सुधार सकता है।
            </motion.p>
            <motion.p
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 1.5 }}
              className="text-center"
            >
              <span className="text-2xl text-teal-300 font-bold">
                "अंगदान — महादान"
              </span>
              <span className="text-teal-300 font-bold">"</span>
            </motion.p>
          </div>
        </motion.div>

        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.7 }}
          className="mt-6 flex flex-wrap justify-center gap-3"
        >
          {['🫀 Heart', '🫁 Lungs', '🟤 Liver', '🫘 Kidneys', '👁️ Eyes', '🦴 Bones'].map(
            (organ, idx) => (
              <motion.span
                key={idx}
                animate={{ y: [0, -5, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: idx * 0.2 }}
                className="bg-white/10 rounded-full px-4 py-2 text-white text-sm border border-white/10"
              >
                {organ}
              </motion.span>
            )
          )}
        </motion.div>
      </div>
    </div>
  );
}

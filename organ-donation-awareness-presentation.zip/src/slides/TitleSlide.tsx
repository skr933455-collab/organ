import { motion } from 'framer-motion';
import { Heart, Calendar, MapPin, User, Users } from 'lucide-react';

export default function TitleSlide() {
  return (
    <div className="h-full w-full relative flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url('/images/nss-logo.jpg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-teal-900/90 via-slate-900/85 to-emerald-900/90" />

      {/* Floating Particles */}
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-teal-400/30 rounded-full"
          animate={{
            y: [0, -100, 0],
            x: [0, Math.random() * 50 - 25, 0],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 3 + Math.random() * 3,
            repeat: Infinity,
            delay: Math.random() * 3,
          }}
          style={{
            left: `${Math.random() * 100}%`,
            top: `${60 + Math.random() * 40}%`,
          }}
        />
      ))}

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl">
        {/* NSS Badge */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', delay: 0.2 }}
          className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-full px-6 py-2 mb-6"
        >
          <span className="text-white font-semibold text-sm tracking-wider">
            🇮🇳 NATIONAL SERVICE SCHEME (NSS)
          </span>
        </motion.div>

        {/* Main Title */}
        <motion.h1
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-4xl sm:text-5xl md:text-7xl font-extrabold text-white mb-2 leading-tight"
        >
          अंगदान
        </motion.h1>

        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4"
        >
          <span className="bg-gradient-to-r from-teal-300 via-emerald-300 to-green-300 bg-clip-text text-transparent">
            जीवन संजीवनी अभियान
          </span>
        </motion.div>

        <motion.p
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-lg sm:text-xl text-teal-200/80 mb-8 font-medium"
        >
          "एक अंगदान - आठ जिंदगियाँ" | Organ Donation Awareness Programme
        </motion.p>

        {/* Animated Heart */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', delay: 1 }}
          className="mb-8"
        >
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="inline-flex items-center justify-center w-20 h-20 bg-red-500/20 rounded-full border-2 border-red-400/40"
          >
            <Heart className="w-10 h-10 text-red-400" fill="currentColor" />
          </motion.div>
        </motion.div>

        {/* Event Details Grid */}
        <motion.div
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-2xl mx-auto"
        >
          <div className="bg-white/10 backdrop-blur-sm rounded-xl px-4 py-3 border border-white/10 flex items-center gap-3">
            <Calendar className="w-5 h-5 text-teal-300 shrink-0" />
            <div className="text-left">
              <p className="text-white/50 text-xs">Date</p>
              <p className="text-white font-semibold text-sm">Tuesday, 2026</p>
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl px-4 py-3 border border-white/10 flex items-center gap-3">
            <MapPin className="w-5 h-5 text-emerald-300 shrink-0" />
            <div className="text-left">
              <p className="text-white/50 text-xs">Venue</p>
              <p className="text-white font-semibold text-sm">TN Campus & Hargaon Village</p>
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl px-4 py-3 border border-white/10 flex items-center gap-3">
            <User className="w-5 h-5 text-amber-300 shrink-0" />
            <div className="text-left">
              <p className="text-white/50 text-xs">Convener</p>
              <p className="text-white font-semibold text-sm">Dr. Rahul Kumar Pandey (Principal, TNACE)</p>
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl px-4 py-3 border border-white/10 flex items-center gap-3">
            <Users className="w-5 h-5 text-pink-300 shrink-0" />
            <div className="text-left">
              <p className="text-white/50 text-xs">Coordinator</p>
              <p className="text-white font-semibold text-sm">Dr. P.M. Jena Ma'am (Asst. Prof., TSC)</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

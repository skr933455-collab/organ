import { motion } from 'framer-motion';

export default function TypesOfDonation() {
  return (
    <div className="h-full w-full flex items-center justify-center overflow-y-auto p-6">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="mb-6"
        >
          <p className="text-teal-400 text-sm font-semibold tracking-wider uppercase">Slide 04</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            अंगदान के प्रकार (Types of Organ Donation)
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Living Donation */}
          <motion.div
            initial={{ x: -80, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3, type: 'spring' }}
            className="bg-gradient-to-br from-emerald-900/60 to-green-900/40 rounded-2xl p-6 border border-emerald-400/30 relative overflow-hidden"
          >
            <motion.div
              className="absolute -top-8 -right-8 w-32 h-32 bg-emerald-400/10 rounded-full"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 3, repeat: Infinity }}
            />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                <motion.span
                  className="text-4xl"
                  animate={{ y: [0, -5, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  🟢
                </motion.span>
                <div>
                  <h3 className="text-2xl font-bold text-emerald-300">जीवित दान</h3>
                  <p className="text-emerald-200/70 text-sm">Living Donation</p>
                </div>
              </div>

              <div className="space-y-3">
                {[
                  { text: 'जीवित व्यक्ति अपना एक अंग दान करता है', en: 'A living person donates one of their organs' },
                  { text: 'आमतौर पर एक किडनी या लिवर का हिस्सा दिया जाता है', en: 'Usually one kidney or part of liver is donated' },
                  { text: 'दाता सामान्य जीवन जी सकता है', en: 'Donor can live a normal life afterwards' },
                  { text: 'परिवार के सदस्य या करीबी रिश्तेदार दान कर सकते हैं', en: 'Family members or close relatives can donate' },
                  { text: 'Bone Marrow भी जीवित दान में आता है', en: 'Bone marrow also falls under living donation' },
                ].map((point, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ x: -30, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.5 + idx * 0.1 }}
                    className="flex items-start gap-2 bg-emerald-500/10 rounded-lg p-2.5"
                  >
                    <span className="text-emerald-400 mt-0.5">✅</span>
                    <div>
                      <p className="text-white/90 text-sm font-medium">{point.text}</p>
                      <p className="text-white/50 text-xs italic">{point.en}</p>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-4 bg-emerald-500/10 rounded-lg p-3 border border-emerald-500/20">
                <p className="text-emerald-200 text-xs font-semibold">
                  📊 भारत में 80% से ज़्यादा किडनी ट्रांसप्लांट जीवित दाताओं से होते हैं
                </p>
              </div>
            </div>
          </motion.div>

          {/* Deceased Donation */}
          <motion.div
            initial={{ x: 80, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.5, type: 'spring' }}
            className="bg-gradient-to-br from-blue-900/60 to-indigo-900/40 rounded-2xl p-6 border border-blue-400/30 relative overflow-hidden"
          >
            <motion.div
              className="absolute -top-8 -right-8 w-32 h-32 bg-blue-400/10 rounded-full"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 3, repeat: Infinity, delay: 1.5 }}
            />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                <motion.span
                  className="text-4xl"
                  animate={{ y: [0, -5, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 1 }}
                >
                  🔵
                </motion.span>
                <div>
                  <h3 className="text-2xl font-bold text-blue-300">मृत्यु के बाद दान</h3>
                  <p className="text-blue-200/70 text-sm">Deceased / Cadaveric Donation</p>
                </div>
              </div>

              <div className="space-y-3">
                {[
                  { text: 'Brain Death (ब्रेन डेथ) के बाद अंगदान किया जाता है', en: 'Organs are donated after brain death is declared' },
                  { text: 'Heart, Lungs, Liver, Kidneys सब दान हो सकते हैं', en: 'Heart, Lungs, Liver, Kidneys — all can be donated' },
                  { text: 'एक मृत दाता 8 जिंदगियाँ बचा सकता है', en: 'One deceased donor can save up to 8 lives' },
                  { text: 'Cornea दान सामान्य मृत्यु के बाद भी हो सकता है', en: 'Cornea donation can happen after natural death too' },
                  { text: 'परिवार की सहमति आवश्यक होती है', en: 'Family consent is mandatory' },
                ].map((point, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ x: 30, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.7 + idx * 0.1 }}
                    className="flex items-start gap-2 bg-blue-500/10 rounded-lg p-2.5"
                  >
                    <span className="text-blue-400 mt-0.5">💙</span>
                    <div>
                      <p className="text-white/90 text-sm font-medium">{point.text}</p>
                      <p className="text-white/50 text-xs italic">{point.en}</p>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-4 bg-blue-500/10 rounded-lg p-3 border border-blue-500/20">
                <p className="text-blue-200 text-xs font-semibold">
                  ⚠️ Brain Death ≠ Heart Stop — Brain Dead होने पर भी शरीर के अंग काम करते रहते हैं
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Brain Death Explanation */}
        <motion.div
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="mt-5 bg-gradient-to-r from-amber-900/40 to-orange-900/30 rounded-xl p-4 border border-amber-500/20"
        >
          <h4 className="text-amber-300 font-bold text-sm mb-2">🧠 Brain Death (ब्रेन डेथ) क्या है?</h4>
          <p className="text-white/70 text-xs">
            जब मस्तिष्क पूरी तरह काम करना बंद कर देता है और कभी ठीक नहीं हो सकता — यह कानूनी तौर पर मृत्यु मानी जाती है।
            इस स्थिति में ventilator से शरीर के बाकी अंग काम करते रहते हैं, जिन्हें दान किया जा सकता है।
            <span className="text-amber-200 italic"> 4 डॉक्टरों की टीम Brain Death को certify करती है।</span>
          </p>
        </motion.div>
      </div>
    </div>
  );
}

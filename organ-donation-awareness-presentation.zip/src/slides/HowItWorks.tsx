import { motion } from 'framer-motion';

const steps = [
  { num: '01', emoji: '📝', title: 'रजिस्ट्रेशन', titleEn: 'Registration', desc: 'NOTTO या राज्य की वेबसाइट पर अंगदान के लिए रजिस्टर करें। Donor Card प्राप्त करें।', color: 'bg-teal-500', glow: 'shadow-teal-500/30' },
  { num: '02', emoji: '👨‍👩‍👧‍👦', title: 'परिवार को बताएं', titleEn: 'Inform Family', desc: 'अपने परिवार और करीबियों को अपने अंगदान के निर्णय के बारे में बताएं। उनकी सहमति ज़रूरी है।', color: 'bg-blue-500', glow: 'shadow-blue-500/30' },
  { num: '03', emoji: '🏥', title: 'ब्रेन डेथ घोषणा', titleEn: 'Brain Death Declaration', desc: '4 विशेषज्ञ डॉक्टरों की टीम Brain Death को प्रमाणित करती है। यह कानूनी प्रक्रिया है।', color: 'bg-purple-500', glow: 'shadow-purple-500/30' },
  { num: '04', emoji: '🔄', title: 'अंग मिलान', titleEn: 'Organ Matching', desc: 'NOTTO/ROTTO कंप्यूटर सिस्टम से सबसे जरूरतमंद मरीज़ का मिलान किया जाता है — Blood group, tissue matching।', color: 'bg-amber-500', glow: 'shadow-amber-500/30' },
  { num: '05', emoji: '✂️', title: 'अंग निकालना', titleEn: 'Organ Retrieval', desc: 'ऑपरेशन थिएटर में trained surgeons अंगों को सावधानी से निकालते हैं। शरीर का पूरा सम्मान रखा जाता है।', color: 'bg-red-500', glow: 'shadow-red-500/30' },
  { num: '06', emoji: '🚑', title: 'तेज़ परिवहन', titleEn: 'Green Corridor Transport', desc: 'अंगों को तुरंत Green Corridor (ट्रैफ़िक-फ़्री रूट) से अस्पताल तक पहुँचाया जाता है।', color: 'bg-green-500', glow: 'shadow-green-500/30' },
  { num: '07', emoji: '🫀', title: 'ट्रांसप्लांट सर्जरी', titleEn: 'Transplant Surgery', desc: 'मरीज़ के खराब अंग को हटाकर, दान किया गया स्वस्थ अंग प्रत्यारोपित किया जाता है।', color: 'bg-pink-500', glow: 'shadow-pink-500/30' },
  { num: '08', emoji: '🌟', title: 'नई ज़िंदगी!', titleEn: 'New Life Begins!', desc: 'मरीज़ को नया जीवन मिलता है! अंगदाता का परिवार गर्व से कह सकता है — हमने जीवन दिया!', color: 'bg-emerald-500', glow: 'shadow-emerald-500/30' },
];

export default function HowItWorks() {
  return (
    <div className="h-full w-full flex items-center justify-center overflow-y-auto p-6">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="mb-5"
        >
          <p className="text-teal-400 text-sm font-semibold tracking-wider uppercase">Slide 05</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            अंगदान कैसे होता है? (How Does It Work?)
          </h2>
          <p className="text-white/50 text-sm mt-1">Step-by-step organ donation process</p>
        </motion.div>

        <div className="relative">
          {/* Connecting Line */}
          <div className="hidden md:block absolute left-[22px] top-4 bottom-4 w-0.5 bg-gradient-to-b from-teal-500 via-purple-500 to-emerald-500 opacity-30" />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {steps.map((step, idx) => (
              <motion.div
                key={idx}
                initial={{ x: idx % 2 === 0 ? -60 : 60, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.15 * idx, type: 'spring', stiffness: 150 }}
                className={`relative flex items-start gap-3 bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10 hover:border-white/25 transition-all group`}
              >
                <motion.div
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.5 }}
                  className={`${step.color} ${step.glow} shadow-lg w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xs shrink-0`}
                >
                  {step.num}
                </motion.div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{step.emoji}</span>
                    <div>
                      <h4 className="text-white font-bold text-sm">{step.title}</h4>
                      <p className="text-white/40 text-xs">{step.titleEn}</p>
                    </div>
                  </div>
                  <p className="text-white/60 text-xs mt-1.5 leading-relaxed">{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="mt-4 rounded-xl overflow-hidden border border-white/10"
        >
          <img
            src="/images/donation-process.jpg"
            alt="Donation Process"
            className="w-full h-32 sm:h-40 object-cover"
          />
        </motion.div>
      </div>
    </div>
  );
}

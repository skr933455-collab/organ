import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronLeft,
  ChevronRight,
  Heart,
  Download,
} from 'lucide-react';
import { generateOrganDonationPPT } from './utils/generatePPT';

import TitleSlide from './slides/TitleSlide';
import WhatIsOrganDonation from './slides/WhatIsOrganDonation';
import WhichOrgans from './slides/WhichOrgans';
import TypesOfDonation from './slides/TypesOfDonation';
import HowItWorks from './slides/HowItWorks';
import WhyImportant from './slides/WhyImportant';
import IndiaStats from './slides/IndiaStats';
import MythsFacts from './slides/MythsFacts';
import LegalFramework from './slides/LegalFramework';
import HowToRegister from './slides/HowToRegister';
import SuccessStories from './slides/SuccessStories';
import PledgeSlide from './slides/PledgeSlide';
import ThankYouSlide from './slides/ThankYouSlide';

const slides = [
  TitleSlide,
  WhatIsOrganDonation,
  WhichOrgans,
  TypesOfDonation,
  HowItWorks,
  WhyImportant,
  IndiaStats,
  MythsFacts,
  LegalFramework,
  HowToRegister,
  SuccessStories,
  PledgeSlide,
  ThankYouSlide,
];

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [direction, setDirection] = useState(0);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      const result = await generateOrganDonationPPT();
      if (result.success && result.data) {
        // Create a download link manually
        const url = window.URL.createObjectURL(result.data as Blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'Angdaan_Jeevan_Sanjeevani_Abhiyan_NSS.pptx';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      } else {
        alert('PPT generation failed. Please try again.');
      }
    } catch (err) {
      console.error(err);
      alert('An error occurred while generating the PPT.');
    } finally {
      setIsDownloading(false);
    }
  };

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setDirection(1);
      setCurrentSlide((prev) => prev + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setDirection(-1);
      setCurrentSlide((prev) => prev - 1);
    }
  };

  const goToSlide = (index: number) => {
    setDirection(index > currentSlide ? 1 : -1);
    setCurrentSlide(index);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault();
        nextSlide();
      }
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        prevSlide();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlide]);

  const SlideComponent = slides[currentSlide];

  const variants = {
    enter: (dir: number) => ({
      x: dir > 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.95,
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
    },
    exit: (dir: number) => ({
      x: dir < 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.95,
    }),
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900 flex flex-col overflow-hidden">
      {/* Top Bar */}
      <div className="bg-black/30 backdrop-blur-sm px-4 py-2 flex items-center justify-between z-20 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Heart className="w-5 h-5 text-red-400 animate-pulse" />
          <span className="text-white/80 text-sm font-medium">
            अंगदान जीवन संजीवनी अभियान | NSS Programme
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-white/60 text-sm hidden sm:inline">
            Slide {currentSlide + 1} / {slides.length}
          </span>
          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-white text-sm font-medium transition-all ${
              isDownloading 
                ? 'bg-emerald-800 cursor-not-allowed' 
                : 'bg-emerald-600 hover:bg-emerald-500'
            }`}
          >
            <Download className={`w-4 h-4 ${isDownloading ? 'animate-bounce' : ''}`} />
            <span>{isDownloading ? 'Generating...' : 'Download PPT'}</span>
          </button>
        </div>
      </div>

      {/* Main Slide Area */}
      <div className="flex-1 relative overflow-hidden">
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentSlide}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: 'spring', stiffness: 300, damping: 30 },
              opacity: { duration: 0.3 },
            }}
            className="absolute inset-0"
          >
            <SlideComponent />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation */}
      <div className="bg-black/40 backdrop-blur-sm px-4 py-3 flex items-center justify-between z-20 border-t border-white/10">
        <button
          onClick={prevSlide}
          disabled={currentSlide === 0}
          className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed rounded-lg text-white transition-all duration-300"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="hidden sm:inline">Previous</span>
        </button>

        {/* Slide Dots */}
        <div className="flex gap-1.5 flex-wrap justify-center max-w-md">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                index === currentSlide
                  ? 'bg-teal-400 w-8'
                  : 'bg-white/30 hover:bg-white/50'
              }`}
            />
          ))}
        </div>

        <button
          onClick={nextSlide}
          disabled={currentSlide === slides.length - 1}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-500 disabled:opacity-30 disabled:cursor-not-allowed rounded-lg text-white transition-all duration-300"
        >
          <span className="hidden sm:inline">Next</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
